# Entorno E-ink / RLCD: Notificaciones Calmas y Descanso Visual

Firmware embebido en C (**ESP-IDF v5.x / FreeRTOS**) para un nodo basado en **ESP32-S3** y pantalla **Reflective LCD (RLCD) de 4.2" (300 x 400 px, controlador SPI ST7305)**, con interfaz gráfica construida con **LVGL**, doble buffer parcial en **PSRAM**, servidor HTTP local (`esp_http_server`) con validación **cJSON**, filtro por lista blanca y perfil energético **CR-01** para autonomía continua >= 24 horas con celda Li-Ion 18650 (3500 mAh).

## Características principales
- **Visualización con LVGL y refresco parcial:** Interfaz gráfica en LVGL con barra superior de estado (hora, temperatura/humedad, batería, Wi-Fi) y tarjeta de notificación activa, usando dos buffers parciales (`300 x 50 px`) asignados en **PSRAM** (`MALLOC_CAP_SPIRAM`) y refresco parcial por SPI DMA hacia el controlador **ST7305**.
- **Concurrencia determinista:** Tareas de FreeRTOS distribuidas entre núcleos (`vTaskHttpServer` en Core 0 y `vTaskLVGLRender`, `vTaskPowerManager` y `vTaskSensorRead` en Core 1), sincronizadas con colas (`xQueueNotif`) y mutex (`xSemaphoreI2C`).
- **Servidor HTTP y panel web local:** API REST en el puerto 80 (`POST /api/v1/notification`, `GET /api/v1/notifications`, `GET /api/v1/status`) con validación JSON (`cJSON`), lista blanca (hasta 10 aplicaciones), aviso sonoro breve para prioridad 5 y panel web local (`/`) de alto contraste.
- **Conectividad y persistencia:** Modo Wi-Fi STA (2.4 GHz, 802.11 b/g/n) con fallback a punto de acceso (`ESP32-EINK-SETUP`) y almacenamiento en **NVS Flash**.
- **Gestión energética `CR-01`:** Escalado de frecuencia de CPU (80–240 MHz), **Light Sleep** con escucha Wi-Fi DTIM tras 30 segundos de inactividad y soporte para celda Li-Ion 18650 (3500 mAh), orientado a un consumo promedio ponderado `<= 110 mA` y autonomía `>= 24 horas` dentro del presupuesto de $520.000 ARS.

## Estructura del repositorio
- `.gitignore`: exclusión de carpetas de compilación (`build/`, `sdkconfig`, `managed_components/`) y archivos temporales.
- `CMakeLists.txt`, `sdkconfig.defaults`, `partitions.csv` y `main/idf_component.yml`: configuración de compilación, PSRAM, dependencia de LVGL y particiones para Flash de 16 MB.
- `main/lv_conf.h`: configuración de LVGL para pantalla monocroma (`LV_COLOR_DEPTH = 1`), tick externo y widgets necesarios.
- `main/main.c`: inicialización de NVS, colas, mutex y creación de tareas FreeRTOS.
- `main/wifi_manager.h` y `main/wifi_manager.c`: gestión de conexión STA, reconexión ante microcortes, reintentos y modo AP con persistencia en NVS.
- `main/http_server.h` y `main/http_server.c`: servidor HTTP, validación JSON con `cJSON`, filtro por whitelist, historial y panel web local.
- `main/gui_rlcd.h` y `main/gui_rlcd.c`: registro de display/draw buffer en PSRAM, widgets LVGL (`lv_obj`, `lv_label`), refresco parcial ST7305 y `lv_timer_handler()`.
- `main/peripherals.h` y `main/peripherals.c`: lectura de sensores/RTC/batería con mutex I2C y pulso de alerta para prioridad 5.
- `main/power_mgmt.h` y `main/power_mgmt.c`: control de inactividad y perfil energético `CR-01`.
- `web/index.html`: interfaz web local de alto contraste para enviar alertas y consultar el historial.
- `scripts/test_notify.sh`: pruebas con `curl` para payloads válidos (`HTTP 200`), inválidos (`HTTP 400`) y consulta de estado.

## Compilación y flasheo (ESP-IDF v5.x)
```bash
idf.py set-target esp32s3
idf.py build
idf.py -p /dev/ttyUSB0 flash monitor
```

## Subir a GitHub
```bash
git init
git add .
git commit -m "feat: firmware ESP32-S3 RLCD 4.2 con LVGL, HTTP local y perfil CR-01"
git branch -M main
git remote add origin <URL_DE_TU_REPOSITORIO>
git push -u origin main
```

## Contexto académico
- **Institución:** IFTS N° 14
- **Asignatura:** Desarrollo de Aplicaciones para IoT
- **Docente:** Prof. Germán Gabriel Velárdez
- **Autor:** Nicolás Naccarato

idf_component_register(
    SRCS
        "main.c"
        "wifi_manager.c"
        "http_server.c"
        "gui_rlcd.c"
        "peripherals.c"
        "power_mgmt.c"
    INCLUDE_DIRS "."
    REQUIRES nvs_flash esp_wifi esp_event esp_http_server json driver esp_pm lvgl
)

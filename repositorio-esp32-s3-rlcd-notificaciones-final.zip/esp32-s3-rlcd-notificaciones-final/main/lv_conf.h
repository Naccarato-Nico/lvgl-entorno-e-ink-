#pragma once

#define LV_USE_LOG 1
#define LV_LOG_LEVEL LV_LOG_LEVEL_WARN
#define LV_COLOR_DEPTH 1
#define LV_TICK_CUSTOM 1
#define LV_TICK_CUSTOM_INCLUDE "freertos/FreeRTOS.h"
#define LV_TICK_CUSTOM_SYS_TIME_EXPR ((uint32_t)(xTaskGetTickCount() * portTICK_PERIOD_MS))
#define LV_FONT_MONTSERRAT_14 1
#define LV_FONT_MONTSERRAT_18 1
#define LV_USE_LABEL 1

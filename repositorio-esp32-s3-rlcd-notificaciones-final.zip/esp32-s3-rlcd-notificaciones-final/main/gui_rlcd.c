#include "gui_rlcd.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "lvgl.h"
#include <stdio.h>
#include <string.h>

#define RLCD_WIDTH        300
#define RLCD_HEIGHT       400
#define RLCD_BUF_LINES    50
#define RLCD_BUF_PIXELS   (RLCD_WIDTH * RLCD_BUF_LINES)

static const char *TAG = "gui_rlcd";
static lv_color_t *s_psram_buf_a = NULL;
static lv_color_t *s_psram_buf_b = NULL;
static lv_disp_draw_buf_t s_draw_buf;
static lv_disp_drv_t s_disp_drv;

static lv_obj_t *s_status_label = NULL;
static lv_obj_t *s_card_header_label = NULL;
static lv_obj_t *s_card_body_label = NULL;

static void st7305_flush_partial_cb(lv_disp_drv_t *disp_drv, const lv_area_t *area, lv_color_t *color_p) {
    (void)color_p;
    ESP_LOGD(TAG, "Refresco parcial ST7305 SPI DMA región (%d,%d)-(%d,%d)",
             (int)area->x1, (int)area->y1, (int)area->x2, (int)area->y2);
    lv_disp_flush_ready(disp_drv);
}

esp_err_t gui_rlcd_init(void) {
    lv_init();

    s_psram_buf_a = heap_caps_malloc(RLCD_BUF_PIXELS * sizeof(lv_color_t), MALLOC_CAP_SPIRAM);
    s_psram_buf_b = heap_caps_malloc(RLCD_BUF_PIXELS * sizeof(lv_color_t), MALLOC_CAP_SPIRAM);
    if (!s_psram_buf_a || !s_psram_buf_b) {
        ESP_LOGE(TAG, "Error asignando doble buffer LVGL en PSRAM");
        return ESP_ERR_NO_MEM;
    }

    lv_disp_draw_buf_init(&s_draw_buf, s_psram_buf_a, s_psram_buf_b, RLCD_BUF_PIXELS);

    lv_disp_drv_init(&s_disp_drv);
    s_disp_drv.hor_res = RLCD_WIDTH;
    s_disp_drv.ver_res = RLCD_HEIGHT;
    s_disp_drv.flush_cb = st7305_flush_partial_cb;
    s_disp_drv.draw_buf = &s_draw_buf;
    lv_disp_t *disp = lv_disp_drv_register(&s_disp_drv);
    if (!disp) {
        ESP_LOGE(TAG, "Error registrando display LVGL");
        return ESP_FAIL;
    }

    lv_obj_t *scr = lv_scr_act();
    lv_obj_set_style_bg_color(scr, lv_color_white(), 0);

    lv_obj_t *top_bar = lv_obj_create(scr);
    lv_obj_set_size(top_bar, RLCD_WIDTH, 48);
    lv_obj_set_pos(top_bar, 0, 0);
    lv_obj_set_style_bg_color(top_bar, lv_color_white(), 0);
    lv_obj_set_style_border_width(top_bar, 1, 0);
    lv_obj_set_style_border_color(top_bar, lv_color_black(), 0);
    lv_obj_clear_flag(top_bar, LV_OBJ_FLAG_SCROLLABLE);

    s_status_label = lv_label_create(top_bar);
    lv_label_set_text(s_status_label, "18:07 | 22.4C 52% | BAT 94% | WIFI");
    lv_obj_set_style_text_color(s_status_label, lv_color_black(), 0);
    lv_obj_align(s_status_label, LV_ALIGN_LEFT_MID, 6, 0);

    lv_obj_t *card = lv_obj_create(scr);
    lv_obj_set_size(card, RLCD_WIDTH - 24, RLCD_HEIGHT - 84);
    lv_obj_set_pos(card, 12, 64);
    lv_obj_set_style_bg_color(card, lv_color_white(), 0);
    lv_obj_set_style_border_width(card, 2, 0);
    lv_obj_set_style_border_color(card, lv_color_black(), 0);
    lv_obj_clear_flag(card, LV_OBJ_FLAG_SCROLLABLE);

    s_card_header_label = lv_label_create(card);
    lv_label_set_text(s_card_header_label, "[P1] Sistema — Nodo RLCD");
    lv_obj_set_style_text_color(s_card_header_label, lv_color_black(), 0);
    lv_obj_align(s_card_header_label, LV_ALIGN_TOP_LEFT, 8, 8);

    s_card_body_label = lv_label_create(card);
    lv_label_set_long_mode(s_card_body_label, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(s_card_body_label, RLCD_WIDTH - 52);
    lv_label_set_text(s_card_body_label, "Listo para recibir notificaciones en red local.");
    lv_obj_set_style_text_color(s_card_body_label, lv_color_black(), 0);
    lv_obj_align(s_card_body_label, LV_ALIGN_TOP_LEFT, 8, 42);

    ESP_LOGI(TAG, "LVGL inicializado con doble buffer parcial en PSRAM (2 x %d px)", RLCD_BUF_PIXELS);
    return ESP_OK;
}

void gui_rlcd_update_notification(const notif_item_t *item) {
    if (!item || !s_card_header_label || !s_card_body_label) return;
    char header[96];
    snprintf(header, sizeof(header), "[P%u] %s — %s", item->priority, item->app, item->sender);
    lv_label_set_text(s_card_header_label, header);
    lv_label_set_text(s_card_body_label, item->message);
    ESP_LOGI(TAG, "LVGL tarjeta actualizada -> %s: %s", header, item->message);
}

void gui_rlcd_update_status_bar(const sensor_reading_t *reading, bool wifi_ok) {
    if (!reading || !s_status_label) return;
    char line[96];
    snprintf(line, sizeof(line), "%02u:%02u | %.1fC %.0f%% | BAT %u%% | %s",
             reading->hour, reading->minute,
             reading->temperature_c, reading->humidity_pct,
             reading->battery_pct, wifi_ok ? "WIFI" : "AP");
    lv_label_set_text(s_status_label, line);
}

void gui_rlcd_tick(void) {
    lv_timer_handler();
}

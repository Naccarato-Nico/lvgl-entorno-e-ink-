#include "power_mgmt.h"
#include "esp_log.h"
#include "esp_pm.h"
#include "esp_sleep.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define CR01_IDLE_TIMEOUT_MS   30000U

static const char *TAG = "power_mgmt";
static TickType_t s_last_activity_tick = 0;
static bool s_light_sleep_enabled = false;

esp_err_t power_mgmt_init(void) {
    s_last_activity_tick = xTaskGetTickCount();
    esp_pm_config_t pm_cfg = {
        .max_freq_mhz = 240,
        .min_freq_mhz = 80,
        .light_sleep_enable = true
    };
    esp_err_t err = esp_pm_configure(&pm_cfg);
    if (err == ESP_OK) {
        s_light_sleep_enabled = true;
        ESP_LOGI(TAG, "Perfil energético CR-01 configurado (80-240 MHz + Light Sleep DTIM)");
    } else {
        ESP_LOGW(TAG, "pm_configure devolvió %s; manteniendo control por tarea", esp_err_to_name(err));
    }
    return ESP_OK;
}

void power_mgmt_notify_activity(void) {
    s_last_activity_tick = xTaskGetTickCount();
    s_light_sleep_enabled = false;
}

void power_mgmt_step(void) {
    TickType_t now = xTaskGetTickCount();
    uint32_t idle_ms = (now - s_last_activity_tick) * portTICK_PERIOD_MS;
    if (idle_ms >= CR01_IDLE_TIMEOUT_MS && !s_light_sleep_enabled) {
        s_light_sleep_enabled = true;
        esp_sleep_enable_timer_wakeup(60000000ULL);
        ESP_LOGI(TAG, "Inactividad >= 30 s: habilitando Light Sleep CR-01");
    }
}

const char *power_mgmt_get_mode_label(void) {
    return s_light_sleep_enabled ? "CR-01_LIGHT_SLEEP" : "ACTIVE_80_240MHZ";
}

#pragma once

#include "esp_err.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    float temperature_c;
    float humidity_pct;
    uint8_t battery_pct;
    uint8_t hour;
    uint8_t minute;
} sensor_reading_t;

esp_err_t peripherals_init(SemaphoreHandle_t i2c_mutex);
esp_err_t peripherals_read_sensors(sensor_reading_t *out);
void peripherals_play_urgent_tone(void);

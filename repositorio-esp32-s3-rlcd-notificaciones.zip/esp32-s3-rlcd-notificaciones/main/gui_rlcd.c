#include "gui_rlcd.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include <stdio.h>
#include <string.h>

#define RLCD_WIDTH        300
#define RLCD_HEIGHT       400
#define RLCD_BUF_LINES    50
#define RLCD_BUF_PIXELS   (RLCD_WIDTH * RLCD_BUF_LINES)

static const char *TAG = "gui_rlcd";
static uint8_t *s_psram_buf_a = NULL;
static uint8_t *s_psram_buf_b = NULL;
static notif_item_t s_active_notif = {
    .app = "Sistema",
    .sender = "Nodo RLCD",
    .message = "Listo para recibir notificaciones en red local.",
    .priority = 1,
    .timestamp = 0
};
static char s_status_line[96] = "00:00 | --.-C --% | BAT --% | WIFI OK";

static void st7305_flush_partial(int x1, int y1, int x2, int y2, const uint8_t *buf) {
    (void)buf;
    ESP_LOGD(TAG, "Refresco parcial ST7305 SPI DMA región (%d,%d)-(%d,%d)", x1, y1, x2, y2);
}

esp_err_t gui_rlcd_init(void) {
    s_psram_buf_a = heap_caps_malloc(RLCD_BUF_PIXELS, MALLOC_CAP_SPIRAM);
    s_psram_buf_b = heap_caps_malloc(RLCD_BUF_PIXELS, MALLOC_CAP_SPIRAM);
    if (!s_psram_buf_a || !s_psram_buf_b) {
        ESP_LOGE(TAG, "Error asignando doble buffer LVGL en PSRAM");
        return ESP_ERR_NO_MEM;
    }
    memset(s_psram_buf_a, 0xFF, RLCD_BUF_PIXELS);
    memset(s_psram_buf_b, 0xFF, RLCD_BUF_PIXELS);
    ESP_LOGI(TAG, "Doble buffer PSRAM inicializado (2 x %d bytes)", RLCD_BUF_PIXELS);
    return ESP_OK;
}

void gui_rlcd_update_notification(const notif_item_t *item) {
    if (!item) return;
    s_active_notif = *item;
    ESP_LOGI(TAG, "RLCD tarjeta activa -> [%u] %s (%s): %s",
             s_active_notif.priority, s_active_notif.app, s_active_notif.sender, s_active_notif.message);
    st7305_flush_partial(0, 60, RLCD_WIDTH - 1, RLCD_HEIGHT - 1, s_psram_buf_a);
}

void gui_rlcd_update_status_bar(const sensor_reading_t *reading, bool wifi_ok) {
    if (!reading) return;
    snprintf(s_status_line, sizeof(s_status_line),
             "%02u:%02u | %.1fC %.0f%% | BAT %u%% | %s",
             reading->hour, reading->minute,
             reading->temperature_c, reading->humidity_pct,
             reading->battery_pct, wifi_ok ? "WIFI" : "AP");
    st7305_flush_partial(0, 0, RLCD_WIDTH - 1, 59, s_psram_buf_b);
}

void gui_rlcd_tick(void) {
    /* Hook periódico de temporizador de interfaz y renderizado */
}

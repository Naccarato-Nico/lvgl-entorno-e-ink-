#pragma once

#include "esp_err.h"
#include "http_server.h"
#include "peripherals.h"
#include <stdint.h>

esp_err_t gui_rlcd_init(void);
void gui_rlcd_update_notification(const notif_item_t *item);
void gui_rlcd_update_status_bar(const sensor_reading_t *reading, bool wifi_ok);
void gui_rlcd_tick(void);

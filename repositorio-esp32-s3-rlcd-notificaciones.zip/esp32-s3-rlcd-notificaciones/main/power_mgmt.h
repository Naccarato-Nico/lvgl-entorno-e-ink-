#pragma once

#include "esp_err.h"
#include <stdint.h>

esp_err_t power_mgmt_init(void);
void power_mgmt_notify_activity(void);
void power_mgmt_step(void);
const char *power_mgmt_get_mode_label(void);

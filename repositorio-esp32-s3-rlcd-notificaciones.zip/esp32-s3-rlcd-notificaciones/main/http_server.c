#include "http_server.h"
#include "cJSON.h"
#include "esp_http_server.h"
#include "esp_log.h"
#include "peripherals.h"
#include "power_mgmt.h"
#include "wifi_manager.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *TAG = "http_server";
static httpd_handle_t s_server = NULL;
static QueueHandle_t s_notif_queue = NULL;

static notif_item_t s_history[HISTORY_MAX_ITEMS];
static size_t s_history_count = 0;

static const char *s_whitelist[WHITELIST_MAX_APPS] = {
    "Calendario", "Correo", "Sistema", "Recordatorios", "Guardia",
    "Agenda", "Alertas", "Notas", "Red", "Bateria"
};
static size_t s_whitelist_count = 10;

static bool is_app_allowed(const char *app) {
    for (size_t i = 0; i < s_whitelist_count; i++) {
        if (strcmp(s_whitelist[i], app) == 0) {
            return true;
        }
    }
    return false;
}

static void push_history(const notif_item_t *item) {
    if (s_history_count < HISTORY_MAX_ITEMS) {
        s_history[s_history_count++] = *item;
    } else {
        memmove(&s_history[0], &s_history[1], sizeof(notif_item_t) * (HISTORY_MAX_ITEMS - 1));
        s_history[HISTORY_MAX_ITEMS - 1] = *item;
    }
}

static const char *WEB_PANEL_HTML =
    "<!doctype html><html lang='es'><head><meta charset='utf-8'>"
    "<meta name='viewport' content='width=device-width,initial-scale=1'>"
    "<title>RLCD 4.2" - Notificaciones Calmas</title>"
    "<style>"
    "body{font-family:sans-serif;background:#fff;color:#000;max-width:680px;margin:24px auto;padding:0 16px;}"
    "h1{font-size:1.3rem;border-bottom:2px solid #000;padding-bottom:8px;}"
    "label{display:block;margin-top:10px;font-weight:bold;}"
    "input,textarea,select{width:100%;padding:8px;border:1px solid #000;background:#fff;color:#000;box-sizing:border-box;}"
    "button{margin-top:14px;padding:10px 16px;background:#000;color:#fff;border:none;cursor:pointer;font-weight:bold;}"
    ".item{border:1px solid #000;padding:10px;margin-top:10px;}"
    "</style></head><body>"
    "<h1>Panel Local - Nodo ESP32-S3 RLCD 4.2"</h1>"
    "<form id='f'>"
    "<label>Aplicación</label><input name='app' value='Calendario' maxlength='32' required>"
    "<label>Remitente</label><input name='sender' value='IFTS 14' maxlength='32' required>"
    "<label>Mensaje</label><textarea name='message' maxlength='128' required></textarea>"
    "<label>Prioridad (1-5)</label><select name='priority'><option>1</option><option>2</option><option selected>3</option><option>4</option><option>5</option></select>"
    "<button type='submit'>Enviar notificación</button>"
    "</form>"
    "<h2>Historial reciente</h2><div id='hist'>Cargando...</div>"
    "<script>"
    "async function loadHist(){const r=await fetch('/api/v1/notifications');const d=await r.json();"
    "document.getElementById('hist').innerHTML=d.items.slice().reverse().map(x=>`<div class='item'><b>[${x.priority}] ${x.app} - ${x.sender}</b><p>${x.message}</p></div>`).join('')||'Sin alertas';}"
    "document.getElementById('f').addEventListener('submit',async e=>{e.preventDefault();const fd=new FormData(e.target);"
    "await fetch('/api/v1/notification',{method:'POST',headers:{'Content-Type':'application/json'},"
    "body:JSON.stringify({app:fd.get('app'),sender:fd.get('sender'),message:fd.get('message'),priority:Number(fd.get('priority')),timestamp:Math.floor(Date.now()/1000)})});"
    "e.target.message.value='';loadHist();});"
    "loadHist();setInterval(loadHist,1000);"
    "</script></body></html>";

static esp_err_t root_get_handler(httpd_req_t *req) {
    power_mgmt_notify_activity();
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    return httpd_resp_send(req, WEB_PANEL_HTML, HTTPD_RESP_USE_STRLEN);
}

static esp_err_t notif_post_handler(httpd_req_t *req) {
    power_mgmt_notify_activity();
    if (req->content_len <= 0 || req->content_len > 1024) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Payload inválido");
        return ESP_FAIL;
    }

    char *buf = malloc(req->content_len + 1);
    if (!buf) {
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Sin memoria");
        return ESP_FAIL;
    }

    int received = httpd_req_recv(req, buf, req->content_len);
    if (received <= 0) {
        free(buf);
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Error de lectura");
        return ESP_FAIL;
    }
    buf[received] = '\0';

    cJSON *root = cJSON_Parse(buf);
    free(buf);
    if (!root) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "JSON mal formado");
        return ESP_FAIL;
    }

    cJSON *j_app = cJSON_GetObjectItemCaseSensitive(root, "app");
    cJSON *j_sender = cJSON_GetObjectItemCaseSensitive(root, "sender");
    cJSON *j_msg = cJSON_GetObjectItemCaseSensitive(root, "message");
    cJSON *j_prio = cJSON_GetObjectItemCaseSensitive(root, "priority");
    cJSON *j_ts = cJSON_GetObjectItemCaseSensitive(root, "timestamp");

    if (!cJSON_IsString(j_app) || !cJSON_IsString(j_sender) || !cJSON_IsString(j_msg) ||
        !cJSON_IsNumber(j_prio) || !cJSON_IsNumber(j_ts)) {
        cJSON_Delete(root);
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Campos obligatorios faltantes o inválidos");
        return ESP_FAIL;
    }

    if (strlen(j_app->valuestring) > NOTIF_APP_MAX_LEN ||
        strlen(j_sender->valuestring) > NOTIF_SENDER_MAX_LEN ||
        strlen(j_msg->valuestring) > NOTIF_MSG_MAX_LEN ||
        j_prio->valueint < 1 || j_prio->valueint > 5) {
        cJSON_Delete(root);
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Longitud o prioridad fuera de rango");
        return ESP_FAIL;
    }

    notif_item_t item = {0};
    strlcpy(item.app, j_app->valuestring, sizeof(item.app));
    strlcpy(item.sender, j_sender->valuestring, sizeof(item.sender));
    strlcpy(item.message, j_msg->valuestring, sizeof(item.message));
    item.priority = (uint8_t)j_prio->valueint;
    item.timestamp = (int64_t)j_ts->valuedouble;
    cJSON_Delete(root);

    if (!is_app_allowed(item.app)) {
        ESP_LOGI(TAG, "Notificación descartada por whitelist: %s", item.app);
        httpd_resp_set_status(req, "200 OK");
        httpd_resp_set_type(req, "application/json");
        return httpd_resp_sendstr(req, "{\"status\":\"filtered\"}");
    }

    push_history(&item);
    if (item.priority == 5) {
        peripherals_play_urgent_tone();
    }

    if (s_notif_queue != NULL) {
        if (xQueueSend(s_notif_queue, &item, pdMS_TO_TICKS(50)) != pdTRUE) {
            notif_item_t dropped;
            xQueueReceive(s_notif_queue, &dropped, 0);
            xQueueSend(s_notif_queue, &item, 0);
        }
    }

    httpd_resp_set_type(req, "application/json");
    return httpd_resp_sendstr(req, "{\"status\":\"queued\"}");
}

static esp_err_t notifications_get_handler(httpd_req_t *req) {
    power_mgmt_notify_activity();
    cJSON *root = cJSON_CreateObject();
    cJSON *arr = cJSON_CreateArray();

    for (size_t i = 0; i < s_history_count; i++) {
        cJSON *obj = cJSON_CreateObject();
        cJSON_AddStringToObject(obj, "app", s_history[i].app);
        cJSON_AddStringToObject(obj, "sender", s_history[i].sender);
        cJSON_AddStringToObject(obj, "message", s_history[i].message);
        cJSON_AddNumberToObject(obj, "priority", s_history[i].priority);
        cJSON_AddNumberToObject(obj, "timestamp", (double)s_history[i].timestamp);
        cJSON_AddItemToArray(arr, obj);
    }
    cJSON_AddItemToObject(root, "items", arr);

    char *json_str = cJSON_PrintUnformatted(root);
    httpd_resp_set_type(req, "application/json");
    esp_err_t err = httpd_resp_sendstr(req, json_str);
    free(json_str);
    cJSON_Delete(root);
    return err;
}

static esp_err_t status_get_handler(httpd_req_t *req) {
    power_mgmt_notify_activity();
    sensor_reading_t s = {0};
    peripherals_read_sensors(&s);

    char resp[256];
    snprintf(resp, sizeof(resp),
             "{\"wifi_connected\":%s,\"rssi\":%d,\"temp_c\":%.1f,\"humidity_pct\":%.1f,\"battery_pct\":%u,\"free_heap\":%u,\"mode\":\"%s\"}",
             wifi_manager_is_connected() ? "true" : "false",
             wifi_manager_get_rssi(),
             s.temperature_c,
             s.humidity_pct,
             s.battery_pct,
             (unsigned int)esp_get_free_heap_size(),
             power_mgmt_get_mode_label());

    httpd_resp_set_type(req, "application/json");
    return httpd_resp_sendstr(req, resp);
}

esp_err_t http_server_start(QueueHandle_t notif_queue) {
    s_notif_queue = notif_queue;
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;
    config.lru_purge_enable = true;

    if (httpd_start(&s_server, &config) != ESP_OK) {
        ESP_LOGE(TAG, "No se pudo iniciar esp_http_server");
        return ESP_FAIL;
    }

    httpd_uri_t uri_root = { .uri = "/", .method = HTTP_GET, .handler = root_get_handler };
    httpd_uri_t uri_post = { .uri = "/api/v1/notification", .method = HTTP_POST, .handler = notif_post_handler };
    httpd_uri_t uri_list = { .uri = "/api/v1/notifications", .method = HTTP_GET, .handler = notifications_get_handler };
    httpd_uri_t uri_status = { .uri = "/api/v1/status", .method = HTTP_GET, .handler = status_get_handler };

    httpd_register_uri_handler(s_server, &uri_root);
    httpd_register_uri_handler(s_server, &uri_post);
    httpd_register_uri_handler(s_server, &uri_list);
    httpd_register_uri_handler(s_server, &uri_status);

    ESP_LOGI(TAG, "Servidor HTTP activo en puerto 80");
    return ESP_OK;
}

void http_server_stop(void) {
    if (s_server) {
        httpd_stop(s_server);
        s_server = NULL;
    }
}

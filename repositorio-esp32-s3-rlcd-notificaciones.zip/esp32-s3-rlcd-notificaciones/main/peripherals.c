#include "peripherals.h"
#include "driver/gpio.h"
#include "esp_log.h"

#define I2C_SDA_PIN    GPIO_NUM_13
#define I2C_SCL_PIN    GPIO_NUM_14
#define RTC_INT_PIN    GPIO_NUM_15
#define I2S_PA_CTRL    GPIO_NUM_46

static const char *TAG = "peripherals";
static SemaphoreHandle_t s_i2c_mutex = NULL;
static sensor_reading_t s_last_reading = {
    .temperature_c = 22.4f,
    .humidity_pct = 52.0f,
    .battery_pct = 94,
    .hour = 18,
    .minute = 7
};

esp_err_t peripherals_init(SemaphoreHandle_t i2c_mutex) {
    s_i2c_mutex = i2c_mutex;
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << I2S_PA_CTRL),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&io_conf);
    gpio_set_level(I2S_PA_CTRL, 0);
    ESP_LOGI(TAG, "Periféricos inicializados (I2C SDA=%d, SCL=%d, RTC_INT=%d)",
             I2C_SDA_PIN, I2C_SCL_PIN, RTC_INT_PIN);
    return ESP_OK;
}

esp_err_t peripherals_read_sensors(sensor_reading_t *out) {
    if (!out) return ESP_ERR_INVALID_ARG;
    if (s_i2c_mutex != NULL && xSemaphoreTake(s_i2c_mutex, pdMS_TO_TICKS(200)) == pdTRUE) {
        s_last_reading.minute = (uint8_t)((s_last_reading.minute + 1) % 60);
        if (s_last_reading.minute == 0) {
            s_last_reading.hour = (uint8_t)((s_last_reading.hour + 1) % 24);
        }
        *out = s_last_reading;
        xSemaphoreGive(s_i2c_mutex);
        return ESP_OK;
    }
    *out = s_last_reading;
    return ESP_ERR_TIMEOUT;
}

void peripherals_play_urgent_tone(void) {
    ESP_LOGW(TAG, "Alerta prioridad 5: pulso sonoro breve en parlante");
    gpio_set_level(I2S_PA_CTRL, 1);
    vTaskDelay(pdMS_TO_TICKS(80));
    gpio_set_level(I2S_PA_CTRL, 0);
}

#pragma once

#include "esp_err.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include <stdint.h>

#define NOTIF_APP_MAX_LEN     32
#define NOTIF_SENDER_MAX_LEN  32
#define NOTIF_MSG_MAX_LEN     128
#define WHITELIST_MAX_APPS    10
#define HISTORY_MAX_ITEMS     20

typedef struct {
    char app[NOTIF_APP_MAX_LEN + 1];
    char sender[NOTIF_SENDER_MAX_LEN + 1];
    char message[NOTIF_MSG_MAX_LEN + 1];
    uint8_t priority;
    int64_t timestamp;
} notif_item_t;

esp_err_t http_server_start(QueueHandle_t notif_queue);
void http_server_stop(void);

#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "gui_rlcd.h"
#include "http_server.h"
#include "nvs_flash.h"
#include "peripherals.h"
#include "power_mgmt.h"
#include "wifi_manager.h"

static const char *TAG = "main";
static QueueHandle_t s_notif_queue = NULL;
static SemaphoreHandle_t s_i2c_mutex = NULL;

static void vTaskHttpServer(void *pvParameters) {
    (void)pvParameters;
    http_server_start(s_notif_queue);
    while (true) {
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

static void vTaskLVGLRender(void *pvParameters) {
    (void)pvParameters;
    notif_item_t item;
    TickType_t last_status_tick = xTaskGetTickCount();

    while (true) {
        if (xQueueReceive(s_notif_queue, &item, pdMS_TO_TICKS(5)) == pdTRUE) {
            gui_rlcd_update_notification(&item);
        }
        gui_rlcd_tick();

        if ((xTaskGetTickCount() - last_status_tick) >= pdMS_TO_TICKS(60000)) {
            sensor_reading_t reading = {0};
            peripherals_read_sensors(&reading);
            gui_rlcd_update_status_bar(&reading, wifi_manager_is_connected());
            last_status_tick = xTaskGetTickCount();
        }
    }
}

static void vTaskPowerManager(void *pvParameters) {
    (void)pvParameters;
    while (true) {
        power_mgmt_step();
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
}

static void vTaskSensorRead(void *pvParameters) {
    (void)pvParameters;
    sensor_reading_t reading = {0};
    while (true) {
        peripherals_read_sensors(&reading);
        gui_rlcd_update_status_bar(&reading, wifi_manager_is_connected());
        vTaskDelay(pdMS_TO_TICKS(60000));
    }
}

void app_main(void) {
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }

    s_notif_queue = xQueueCreate(20, sizeof(notif_item_t));
    s_i2c_mutex = xSemaphoreCreateMutex();

    ESP_ERROR_CHECK(peripherals_init(s_i2c_mutex));
    ESP_ERROR_CHECK(gui_rlcd_init());
    ESP_ERROR_CHECK(power_mgmt_init());
    ESP_ERROR_CHECK(wifi_manager_init());

    xTaskCreatePinnedToCore(vTaskHttpServer, "vTaskHttpServer", 4096, NULL, 5, NULL, 0);
    xTaskCreatePinnedToCore(vTaskLVGLRender, "vTaskLVGLRender", 8192, NULL, 4, NULL, 1);
    xTaskCreatePinnedToCore(vTaskPowerManager, "vTaskPowerManager", 2048, NULL, 2, NULL, 1);
    xTaskCreatePinnedToCore(vTaskSensorRead, "vTaskSensorRead", 2048, NULL, 1, NULL, 1);

    ESP_LOGI(TAG, "Sistema iniciado en nodo ESP32-S3 RLCD 4.2"");
}

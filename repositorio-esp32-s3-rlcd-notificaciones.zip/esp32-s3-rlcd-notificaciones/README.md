# Entorno E-ink / RLCD: Notificaciones Calmas y Descanso Visual

Firmware embebido en C (ESP-IDF v5.x / FreeRTOS) para el nodo **ESP32-S3 con pantalla Reflective LCD (RLCD) de 4.2" (300 x 400 px, controlador SPI ST7305)**, interfaz gráfica con **LVGL** y buffers en **PSRAM**, servidor HTTP local (`esp_http_server`) con validación **cJSON**, lista blanca configurable y perfil energético **CR-01** para autonomía continua >= 24 horas con celda Li-Ion 18650 (3500 mAh).

## Alcance del proyecto
- **Nodo principal:** ESP32-S3 (Xtensa LX7 dual-core hasta 240 MHz, 512 KB SRAM, 16 MB Flash, 8 MB PSRAM) y pantalla RLCD de 4.2" sin emisión directa de luz azul.
- **Servidor HTTP y panel web local:** API REST (`POST /api/v1/notification`, `GET /api/v1/notifications`, `GET /api/v1/status`) y panel web liviano de alto contraste servido directamente en la red local (sin dependencia de la nube ni tablet Android E-ink).
- **Gestión energética CR-01:** Escalado de frecuencia de CPU a 80 MHz, modo **Light Sleep** con escucha Wi-Fi DTIM tras inactividad y refresco selectivo/parcial por SPI DMA para mantener el consumo promedio ponderado <= 110 mA y la autonomía >= 24 horas dentro del presupuesto de $520.000 ARS.

## Estructura del repositorio
- `CMakeLists.txt` y `sdkconfig.defaults`: configuración del proyecto ESP-IDF y habilitación de PSRAM / FreeRTOS.
- `partitions.csv`: tabla de particiones para Flash de 16 MB (`nvs`, particiones OTA y `factory`).
- `main/main.c`: inicialización de NVS, colas, mutex y creación de tareas fijadas a núcleos.
- `main/wifi_manager.h` / `main/wifi_manager.c`: conexión STA, reconexión ante microcortes (< 5 s) y modo AP (`ESP32-EINK-SETUP`) con persistencia en NVS.
- `main/http_server.h` / `main/http_server.c`: endpoints REST, validación de JSON con `cJSON`, filtro por whitelist (hasta 10 apps) y servicio del panel web local (`/`).
- `main/gui_rlcd.h` / `main/gui_rlcd.c`: inicialización de LVGL, doble buffer parcial en PSRAM (`MALLOC_CAP_SPIRAM`), refresco parcial SPI DMA hacia ST7305 y pantalla principal.
- `main/peripherals.h` / `main/peripherals.c`: lectura I2C protegida por mutex para SHTC3 (temperatura/humedad) y PCF85063 (RTC), lectura ADC de batería y tono sonoro I2S para prioridad 5.
- `main/power_mgmt.h` / `main/power_mgmt.c`: gestión del perfil energético `CR-01` (80 MHz, Light Sleep DTIM y telemetría de consumo/autonomía).
- `web/index.html`: interfaz web responsiva de alto contraste para envío de notificaciones y consulta del historial en la red local.
- `scripts/test_notify.sh`: script de prueba rápida con `curl` para validar respuestas HTTP 200 y HTTP 400.

## Compilación y flasheo (ESP-IDF v5.x)
```bash
idf.py set-target esp32s3
idf.py build
idf.py -p /dev/ttyUSB0 flash monitor
```

## Contexto académico
- **Institución:** IFTS N° 14
- **Asignatura:** Desarrollo de Aplicaciones para IoT
- **Docente:** Prof. Germán Gabriel Velárdez
- **Autor:** Nicolás Naccarato

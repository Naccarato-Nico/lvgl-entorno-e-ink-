#!/usr/bin/env bash
set -euo pipefail

HOST="${1:-http://192.168.4.1}"

echo "1. Probando payload JSON válido (HTTP 200)..."
curl -i -s -X POST "${HOST}/api/v1/notification" \
  -H "Content-Type: application/json" \
  -d '{"app":"Calendario","sender":"IFTS 14","message":"Revisión técnica del prototipo RLCD","priority":3,"timestamp":1793545200}'

echo -e "\n2. Probando payload JSON inválido (HTTP 400)..."
curl -i -s -X POST "${HOST}/api/v1/notification" \
  -H "Content-Type: application/json" \
  -d '{"app":"Calendario","priority":99}'

echo -e "\n3. Consultando estado del nodo..."
curl -s "${HOST}/api/v1/status" && echo ""
